<a name="1.4.3"></a>
# 1.4.3 (2014-12-08)


## Bug Fixes

- **SNAPSHOT:** Display list of indices from snapshot instead of list of current indices when restoring a snapshot
  ([https://github.com/lmenezes/elasticsearch-kopf/issues/211])
